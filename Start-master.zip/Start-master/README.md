# 基于html开发的在线网址导航

[English Doc](./Readme-en.md)

## 部署步骤

将全部文件复制到服务器，入口文件是index.html


## 在线预览

https://geeeeeeeek.github.io/web_tool/


## 二次开发

1. 如需修改网址，可修改index.html

2. 如需修改关于页面，可修改about里面的index页面


## 参考资料

- https://web-tool-omega.vercel.app/

- https://web-a55.pages.dev/

- https://hrzhanghuan.com
